{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf600
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww13820\viewh9200\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs72 \cf0 React.Js application: Memory Game\
\

\fs28 by Michael Truong\

\fs24 \
Game Overview\
- You will be able to choose from difficulty level of easy(18 pairs), medium(24 pairs), or hard(30 pairs)\
- The main goal is to match every pairs together by guessing which cards to flip over.\
	-If the two cards you flipped over match, they will stay uncovered\
	-If the two cards you flipped over do not match, they will turn back and be covered again.\
\
-Running the Game Locally\
-Once documents have been downloaded,\
	1.Go to directory of the application\
	2. run \'91npm install\'92 or \'91yarn install\'92\
	3. run yarn start\
	4. The browser should then open up automatically with url: http://localhost:3000}