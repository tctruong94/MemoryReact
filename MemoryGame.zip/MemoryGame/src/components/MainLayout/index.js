export { default } from './MainLayoutStyled.js'
