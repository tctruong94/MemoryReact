export { default } from './CardStyled.js'
