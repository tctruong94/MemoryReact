export { default } from './connectedCards.js'
