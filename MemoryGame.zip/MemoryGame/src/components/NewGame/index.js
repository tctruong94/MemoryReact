export { default } from './connectNewGame.js'
