export { default } from './HeaderStyled.js'
