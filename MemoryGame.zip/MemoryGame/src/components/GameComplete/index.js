export { default } from './GameCompleteStyled.js'
